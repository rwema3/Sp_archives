/*
 *file: homework.h
 */

#ifndef HOMEWORK_H
#define HOMEWORK_H

#include <string.h>
#include <iostream>
#include <fstream>
#include <chrono>

#include "NetworkAnalysis.h"

#endif /* HOMEWORK_H */
