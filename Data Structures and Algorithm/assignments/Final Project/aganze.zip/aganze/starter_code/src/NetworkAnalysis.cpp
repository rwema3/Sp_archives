/*
 *file: NetworkAnalysis.cpp
 */
#include "NetworkAnalysis.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>

class UnionFind {
private:
    std::vector<int> parent;
    std::vector<int> rank;

public:
    UnionFind(int size) : parent(size), rank(size, 0) {
        for (int i = 0; i < size; i++) {
            parent[i] = i;
        }
    }

    int find(int node) {
        if (node < 0 || node >= parent.size()) {
            throw std::out_of_range("Node index out of range in find()");
        }
        if (parent[node] != node) {
            parent[node] = find(parent[node]);  // Path compression
        }
        return parent[node];
    }

    void unite(int node1, int node2) {
        int root1 = find(node1);
        int root2 = find(node2);

        if (root1 != root2) {
            // Union by rank
            if (rank[root1] > rank[root2]) {
                parent[root2] = root1;
            } else if (rank[root1] < rank[root2]) {
                parent[root1] = root2;
            } else {
                parent[root2] = root1;
                rank[root1]++;
            }
        }
    }
};

void NetworkAnalysis::getNetworkStatus(char* inputFilePath) {
    std::ifstream file(inputFilePath);
    if (!file.is_open()) {
        std::cerr << "Failed to open file: " << inputFilePath << std::endl;
        return;
    }
    
    std::string line;
    std::getline(file, line); // Read the first line entirely
    std::istringstream iss(line);
    std::string label;
    char equals;
    int numberOfNodes;

    // Attempt to parse the line as 'label = value'
    if (!(iss >> label >> equals >> numberOfNodes) || label != "numberOfNodes" || equals != '=') {
        std::cerr << "Invalid or missing 'numberOfNodes' in the file." << std::endl;
        return;
    }

    UnionFind uf(numberOfNodes + 1);  // Assuming node indexing starts at 1

    int node1, node2;
    char comma;
    while (file >> node1 >> comma >> node2) {
        if (node1 < 1 || node1 > numberOfNodes || node2 < 1 || node2 > numberOfNodes) {
            std::cerr << "Node index out of valid range." << std::endl;
            continue; // Or return, depending on how you want to handle this
        }
        uf.unite(node1, node2);
    }

    int initialRoot = uf.find(1);
    bool isConnected = true;
    for (int i = 2; i <= numberOfNodes; i++) {
        if (uf.find(i) != initialRoot) {
            isConnected = false;
            break;
        }
    }

    std::cout << (isConnected ? "YES" : "NO") << std::endl;
}
