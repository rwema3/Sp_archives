/*
 *file: NetworkAnalysis.h
 */

#ifndef NETWORKANALYSIS_H
#define NETWORKANALYSIS_H

#include <iostream>
#include <fstream>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include "./util/GetMemUsage.h"
#include "./util/LogManager.h"

class NetworkAnalysis{


public:
	/**
	 *
	 *
	 * @param inputFilePath Path of the input file.
	 *
	 * If the input file cannot be read throw an error of type ios_base::failure
	 * Status should be displayed on the screen
	 */
	static void getNetworkStatus(char* inputFilePath);
};

#endif /* NETWORKANALYSIS_H */
