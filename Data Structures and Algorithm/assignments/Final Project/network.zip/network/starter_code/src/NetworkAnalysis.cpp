/*
 *file: NetworkAnalysis.cpp
 */
#include "NetworkAnalysis.h"


void NetworkAnalysis::getNetworkStatus(char* inputFilePath){
	FILE* inFileStream = fopen(inputFilePath, "r");
	if (! inFileStream){
		char message[1024];
		sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
		throw std::ios_base::failure(message);
	}

	LogManager::writePrintfToLog(LogManager::Level::Status,
			"NetworkAnalysis::getNetworkStatus",
			"Starting to process file %s", inputFilePath);


	fclose(inFileStream);
}
