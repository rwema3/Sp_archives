/*
 *      Author: kompalli
 */

#ifndef CONNECTEDITEMS_H
#define CONNECTEDITEMS_H

#include <iostream>
#include <fstream>
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include "./util/GetMemUsage.h"
#include "./util/LogManager.h"
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>

class ConnectedItems{


public:
	/**
	 *
	 *
	 * @param inputFilePath Path of the input file.
	 * @param outputFilePath Path of the output file.
	 * @param topN Number of
	 *
	 * If the input file cannot be read throw an error of type ios_base::failure
	 * If the output file cannot be generated, then throw an error of type ios_base::failure
	 */
	static void getConnectedItems(char* inputFilePath, char* outputFilePath);
};

#endif /* CONNECTEDITEMS_H */
#include "ConnectedItems.h"

struct Point {
    int x, y;
    bool operator<(const Point& p) const {
        if (x == p.x) return y < p.y;
        return x < p.x;
    }
};

struct Connection {
    Point start, end;
};

class Graph {
public:
    std::map<Point, std::set<Point>> adjList;

    void addEdge(Point u, Point v) {
        adjList[u].insert(v);
        adjList[v].insert(u);  // For undirected graph
    }

    std::vector<std::vector<Point>> getConnectedComponents() {
        std::vector<std::vector<Point>> components;
        std::set<Point> visited;

        for (auto& p : adjList) {
            if (visited.find(p.first) == visited.end()) {
                std::vector<Point> component;
                std::queue<Point> q;
                q.push(p.first);
                visited.insert(p.first);

                while (!q.empty()) {
                    Point u = q.front(); q.pop();
                    component.push_back(u);
                    for (Point v : adjList[u]) {
                        if (visited.find(v) == visited.end()) {
                            visited.insert(v);
                            q.push(v);
                        }
                    }
                }
                components.push_back(component);
            }
        }
        return components;
    }
};

void ConnectedItems::getConnectedItems(char* inputFilePath, char* outputFilePath) {
    FILE* inFileStream = fopen(inputFilePath, "r");
    if (!inFileStream) {
        char message[1024];
        sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
        throw std::ios_base::failure(message);
    }

    FILE* outFileStream = fopen(outputFilePath, "w");
    if (!outFileStream) {
        char message[1024];
        sprintf(message, "Cannot open output file for writing: %s", outputFilePath);
        throw std::ios_base::failure(message);
    }

    fprintf(outFileStream, "Format: (x1, y1, x2, y2, group number)\n");

    Graph graph;
    int x1, y1, x2, y2, flag;

    // Read input file and construct the graph
    while (fscanf(inFileStream, "(%d, %d, %d, %d, %d)\n", &x1, &y1, &x2, &y2, &flag) == 5) {
        if (flag == 1) {
            graph.addEdge({x1, y1}, {x2, y2});
        }
    }

    // Process connected components
    auto components = graph.getConnectedComponents();

    // Sort components by size (largest to smallest) and then by coordinates
    std::sort(components.begin(), components.end(), [](const std::vector<Point>& a, const std::vector<Point>& b) {
        if (a.size() != b.size()) return a.size() > b.size();
        return *std::min_element(a.begin(), a.end()) < *std::min_element(b.begin(), b.end());
    });

    // Assign group numbers and print to output file
    int groupNumber = 1;
    for (auto& component : components) {
        for (size_t i = 0; i < component.size() - 1; ++i) {
            fprintf(outFileStream, "(%d, %d, %d, %d, %d)\n", 
                    component[i].x, component[i].y, component[i+1].x, component[i+1].y, groupNumber);
        }
        groupNumber++;
    }

    fclose(inFileStream);
    fclose(outFileStream);
}
