#include "ConnectedItems.h"

struct Point {
    int x, y;
    bool operator<(const Point& p) const {
        if (x == p.x) return y < p.y;
        return x < p.x;
    }
};

struct Connection {
    Point start, end;
};

class Graph {
public:
    std::map<Point, std::set<Point>> adjList;

    void addEdge(Point u, Point v) {
        adjList[u].insert(v);
        adjList[v].insert(u);  // For undirected graph
    }

    std::vector<std::vector<Point>> getConnectedComponents() {
        std::vector<std::vector<Point>> components;
        std::set<Point> visited;

        for (auto& p : adjList) {
            if (visited.find(p.first) == visited.end()) {
                std::vector<Point> component;
                std::queue<Point> q;
                q.push(p.first);
                visited.insert(p.first);

                while (!q.empty()) {
                    Point u = q.front(); q.pop();
                    component.push_back(u);
                    for (Point v : adjList[u]) {
                        if (visited.find(v) == visited.end()) {
                            visited.insert(v);
                            q.push(v);
                        }
                    }
                }
                components.push_back(component);
            }
        }
        return components;
    }
};

void ConnectedItems::getConnectedItems(char* inputFilePath, char* outputFilePath) {
    FILE* inFileStream = fopen(inputFilePath, "r");
    if (!inFileStream) {
        char message[1024];
        sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
        throw std::ios_base::failure(message);
    }

    FILE* outFileStream = fopen(outputFilePath, "w");
    if (!outFileStream) {
        char message[1024];
        sprintf(message, "Cannot open output file for writing: %s", outputFilePath);
        throw std::ios_base::failure(message);
    }

    fprintf(outFileStream, "Format: (x1, y1, x2, y2, group number)\n");

    Graph graph;
    int x1, y1, x2, y2, flag;

    // Read input file and construct the graph
    while (fscanf(inFileStream, "(%d, %d, %d, %d, %d)\n", &x1, &y1, &x2, &y2, &flag) == 5) {
        if (flag == 1) {
            graph.addEdge({x1, y1}, {x2, y2});
        }
    }

    // Process connected components
    auto components = graph.getConnectedComponents();

    // Sort components by size (largest to smallest) and then by coordinates
    std::sort(components.begin(), components.end(), [](const std::vector<Point>& a, const std::vector<Point>& b) {
        if (a.size() != b.size()) return a.size() > b.size();
        return *std::min_element(a.begin(), a.end()) < *std::min_element(b.begin(), b.end());
    });

    // Assign group numbers and print to output file
    int groupNumber = 1;
    for (auto& component : components) {
        for (size_t i = 0; i < component.size() - 1; ++i) {
            fprintf(outFileStream, "(%d, %d, %d, %d, %d)\n", 
                    component[i].x, component[i].y, component[i+1].x, component[i+1].y, groupNumber);
        }
        groupNumber++;
    }

    fclose(inFileStream);
    fclose(outFileStream);
}
