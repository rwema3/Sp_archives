/*
 *  Created on: Dec 22, 2020
 *      Author: kompalli
 */
#include "HuffmanEncoding.h"

void HuffmanEncoding::generateAlphabetCode(char* trainFilePath, char* resultFilePath){

}

void HuffmanEncoding::encodeText(char* testASCIIFilePath, char* huffmanCodeFilePath, char* resultFilePath){

}

void HuffmanEncoding::decodeText(char* testEncodedFilePath, char* huffmanCodeFilePath, char* resultFilePath){

}
