#include <sstream>
#include <iostream>
#include <iomanip> 
#include <iostream>
#include <fstream>
#include "util/GetMemUsage.h"
#include "util/LogManager.h"



struct CodewordNode;

struct HuffmanCode {
    char theChar;
    std::string code;
};

struct CodewordNode {
    char data;
    unsigned occurrence_count;
    CodewordNode* left;
    CodewordNode* right;
    CodewordNode(char data, unsigned occurrence_count);
};


const int MAX_CHAR = 256;

struct HuffmanMap {
    HuffmanCode codes[MAX_CHAR];
    int size;
    HuffmanMap();
    void insert(char theChar, const std::string& code);
    std::string getCode(char theChar);
};

//void enquireHuffmanCodes(char* huffmanCodeFilePath, HuffmanMap& huffmanMap);

class MinHeap {
public:
    MinHeap(int capability);
    ~MinHeap();
    void insert(CodewordNode* element);
    CodewordNode* extractMin();
    int getSize() const;

private:
    CodewordNode** heapArray;  // Array of CodewordNode pointers
    int capability;
    int size;
    void heapifyDown(int i);
    void heapifyUp(int i);
    void swapNode(int a, int b);
    int parent(int i);
    int left(int i);
    int right(int i);
    bool isSmaller(int youngIdx, int rootIdx) const;
};

class HuffmanEncoding{

public:
	/**
	 * Given an input text file, obtain the_occurences of alphabets and generate HuffmanCode.
	 *
	 * @param trainFilePath Path of the input file.
	 * @param resultFilePath Path of the output Huffman code file.
	 *
	 * If the input file cannot be read throw an error of type ios_base::failure
	 * If the output file cannot be generated, then throw an error of type ios_base::failure
	 */
	static void generateAlphabetCode(char* trainFilePath, char* resultFilePath);


	/**
	 * Given an input text file and a file contain the HuffmanCode for alphabets, generate
	 * the encoded file
	 *
	 * @param testASCIIFilePath Path of the input file.
	 * @param huffmanCodeFilePath Path of the alphabet Huffman code file.
	 * @param resultFilePath Path of the output encoded file.
	 *
	 * If the input file cannot be read throw an error of type ios_base::failure
	 * If the output file cannot be generated, then throw an error of type ios_base::failure
	 */
	static void encodeText(char* testASCIIFilePath, char* huffmanCodeFilePath, char* resultFilePath);

	/**
	 * Given an input encoded file and a file contain the HuffmanCode for alphabets, generate
	 * the decoded file
	 *
	 * @param testEncodedFilePath Path of the input encoded file.
	 * @param huffmanCodeFilePath Path of the alphabet Huffman code file.
	 * @param resultFilePath Path of the output decoded file.
	 *
	 * If the input file cannot be read throw an error of type ios_base::failure
	 * If the output file cannot be generated, then throw an error of type ios_base::failure
	 */
	static void decodeText(char* testEncodedFilePath, char* huffmanCodeFilePath, char* resultFilePath);

};
