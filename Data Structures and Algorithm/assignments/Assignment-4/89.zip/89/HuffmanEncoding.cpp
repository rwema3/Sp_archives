#include "HuffmanEncoding.h"
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <iostream>

using namespace std;

// Constructor for CodewordNode
CodewordNode::CodewordNode(char data, unsigned occurrence_count)
    : data(data), occurrence_count(occurrence_count), left(nullptr), right(nullptr) {}

// Constructor for MinHeap
MinHeap::MinHeap(int cap) : capability(cap), size(0) {
    heapArray = new CodewordNode*[capability];
}



// Destructor for MinHeap
MinHeap::~MinHeap() {
    int i = 0;
    while (i < size) {
        delete heapArray[i];
        i++;
    }
    delete[] heapArray;
}



// MinHeap methods
void MinHeap::swapNode(int a, int b) {
    CodewordNode* temp = heapArray[a];
    heapArray[a] = heapArray[b];
    heapArray[b] = temp;
}

// Corrected const-qualified implementations
int MinHeap::parent(int i) { return (i - 1) / 2; }
int MinHeap::left(int i) { return (2 * i + 1); }
int MinHeap::right(int i) { return (2 * i + 2); }

bool MinHeap::isSmaller(int childIdx, int parentIdx) const {
    if (heapArray[childIdx]->occurrence_count == heapArray[parentIdx]->occurrence_count) {
        return heapArray[childIdx]->data < heapArray[parentIdx]->data;
    } else if (heapArray[childIdx]->occurrence_count < heapArray[parentIdx]->occurrence_count) {
        return true;
    } else {
        return false;
    }
}


//Resu
void MinHeap::heapifyDown(int idx) {
    // Get the indices of the left and right children
    int leftChildIdx = left(idx);
    int rightChildIdx = right(idx);
    
    // Initialize the index of the smallest element as the current index
    int smallestIdx = idx;

    // Check if the left child is smaller than the current element
    if (leftChildIdx < size && isSmaller(leftChildIdx, smallestIdx)) {
        smallestIdx = leftChildIdx;
    }

    // Check if the right child is smaller than the current element or the left child
    if (rightChildIdx < size && isSmaller(rightChildIdx, smallestIdx)) {
        smallestIdx = rightChildIdx;
    }

    // If the smallest element is not the current element, swap and continue heapifying down
    if (smallestIdx != idx) {
        swapNode(idx, smallestIdx);
        heapifyDown(smallestIdx);
    }
}


void MinHeap::heapifyUp(int idx) {
    for (; idx > 0 && isSmaller(idx, parent(idx)); idx = parent(idx)) {
        swapNode(idx, parent(idx));
    }
}

//Resu
void MinHeap::insert(CodewordNode* element) {
    if (size == capability) {
        throw std::length_error("it is filled up, this heap");
    }
    heapArray[size] = element;
    size++;
    
    int idx = size - 1;
    while (idx > 0 && isSmaller(idx, parent(idx))) {
        swapNode(idx, parent(idx));
        idx = parent(idx);
    }
}

//Resu
CodewordNode* MinHeap::extractMin() {
    // Check if the heap is empty
    if (size <= 0) {
        throw std::length_error("It is completely vide");
    }
    
    // Extract the minimum element
    CodewordNode* root = heapArray[0];
    
    // Replace root with the last element in the heap
    heapArray[0] = heapArray[size - 1];
    
    // Decrease the size of the heap
    size--;
    
    // Restore heap property
    heapifyDown(0);
    
    return root;
}



int MinHeap::getSize() const {
    return size;  // Implementation of getSize
}

//Resu

// Function to measure the number of occurrences of each theChar in a file
void measureCharacterOccurrences(const char* filePath, int* the_occurences, int& sumofChars) {
    // Initialize the the_occurences array with zeros
    memset(the_occurences, 0, sizeof(int) * 128);
    
    // Open the file
    std::ifstream file(filePath);
    
    // Variable to store each theChar read from the file
    char c;
    
    // Initialize the total theChar count
    sumofChars = 0;
    
    // Iterate through each theChar in the file
    while (file.get(c)) {
        // Ensure the theChar is within the ASCII range (0-127)
        if (c >= 0 && c < 128) {
            // Increment the frequency count for the theChar
            the_occurences[c]++;
            
            // Increment the total theChar count
            sumofChars++;
        }
    }
    
    // Close the file
    file.close();
}



void merge(HuffmanCode arr[], int const left, int const mid, int const right) {
    int const subArrayOneSize = mid - left + 1;
    int const dualSized_SubArray = right - mid;

    // Create temporary arrays
    HuffmanCode* leftArray = new HuffmanCode[subArrayOneSize];
    HuffmanCode* rightArray = new HuffmanCode[dualSized_SubArray];

// Copy data to temporary array 'leftArray'
int i = 0; // Initialize loop control variable
while (i < subArrayOneSize) { // Loop until all elements are copied
    leftArray[i] = arr[left + i]; // Copy element from 'arr' to 'leftArray'
    i++; // Move to the next element in 'leftArray'
}

// Copy data to temporary array 'rightArray'
int j = 0; // Initialize loop control variable
while (j < dualSized_SubArray) { // Loop until all elements are copied
    rightArray[j] = arr[mid + 1 + j]; // Copy element from 'arr' to 'rightArray'
    j++; // Move to the next element in 'rightArray'
}

    // Merge the temporary arrays back into arr[left..right]
    int indexOfLeftArray = 0, the_initial_Array_on_Right = 0;
    int indexOfMergedArray = left;

  do {
    // Compare the codes of the HuffmanCode objects
    if (leftArray[indexOfLeftArray].code <= rightArray[the_initial_Array_on_Right].code) {
        // If the code of the HuffmanCode in the left array is smaller or equal,
        // copy it to the merged array and move to the next element in the left array
        arr[indexOfMergedArray] = leftArray[indexOfLeftArray];
        indexOfLeftArray++;
    } else {
        // If the code of the HuffmanCode in the right array is smaller,
        // copy it to the merged array and move to the next element in the right array
        arr[indexOfMergedArray] = rightArray[the_initial_Array_on_Right];
        the_initial_Array_on_Right++;
    }
    // Move to the next position in the merged array
    indexOfMergedArray++;
// Continue looping while there are elements remaining in both left and right arrays
} while (indexOfLeftArray < subArrayOneSize && the_initial_Array_on_Right < dualSized_SubArray);

   // Copy the remaining elements of leftArray[], if any
do {
    // Copy the element from leftArray to the merged array
    arr[indexOfMergedArray] = leftArray[indexOfLeftArray];
    
    // Move to the next element in leftArray and merged array
    indexOfLeftArray++;
    indexOfMergedArray++;
}

while (indexOfLeftArray < subArrayOneSize);

 // Copy the remaining elements of rightArray[], if any

do {
    // Copy the element from rightArray to the merged array
    arr[indexOfMergedArray] = rightArray[the_initial_Array_on_Right];
    
    // Move to the next element in rightArray and merged array
    the_initial_Array_on_Right++;
    indexOfMergedArray++;
} 

while (the_initial_Array_on_Right < dualSized_SubArray);

    // Deallocate temporary arrays
    delete[] leftArray;
    delete[] rightArray;
}



// Function to perform Merge Sort on an array of HuffmanCode objects
// Parameters:
// arr: Array of HuffmanCode objects to be sorted
// the_initial: Starting index of the subarray
// closure: Ending index of the subarray
void mergeSort(HuffmanCode arr[], int const the_initial, int const closure) {
    // Base case: If subarray has only one element or is empty, return
    if (the_initial >= closure)
        return; // Returns recursively

    // Find the middle index of the subarray
    int mid = the_initial + (closure - the_initial) / 2;

    // Recursively sort the left half of the subarray
    mergeSort(arr, the_initial, mid);

    // Recursively sort the right half of the subarray
    mergeSort(arr, mid + 1, closure);

    // Merge the sorted halves
    merge(arr, the_initial, mid, closure);
}


void generateCodes(CodewordNode* root, const std::string& str, HuffmanCode huffmanCodesArray[], int& index) {
    // Base case: if the current node is null, return
    if (root == nullptr) return;

    // Check if the current node is a leaf node (contains a theChar)
    switch (root->data) {
        // If the data is null ('\0'), it means it's not a leaf node
        // Recursively call generateCodes for the left and right children
        case '\0':
            // For the left child, append '0' to the current path
            generateCodes(root->left, str + "0", huffmanCodesArray, index);
            // For the right child, append '1' to the current path
            generateCodes(root->right, str + "1", huffmanCodesArray, index);
            break;
        // If the data is not null, it means it's a leaf node
        // Add the theChar and its corresponding Huffman code to the array
        default:
            // Add the theChar and its Huffman code to the array
            huffmanCodesArray[index++] = HuffmanCode{root->data, str};
            break;
    }
}


CodewordNode* createHuffmanTree(int* the_occurences) {
    // Create a min heap to store nodes
    MinHeap heap(128);

    // Insert nodes for characters with non-zero occurrences into the heap
    for (int i = 0; i < 128; ++i) {
        if (the_occurences[i] > 0) {
            heap.insert(new CodewordNode(static_cast<char>(i), the_occurences[i]));
        }
    }

    // Continue merging nodes until only one node remains in the heap
    do {
        // Extract two nodes with the lowest frequencies from the heap
        CodewordNode* left = heap.extractMin();
        CodewordNode* right = heap.extractMin();

        // Create a new node representing the sum of the frequencies of the two nodes
        CodewordNode* sum = new CodewordNode('\0', left->occurrence_count + right->occurrence_count);
        sum->left = left;
        sum->right = right;

        // Insert the new node back into the heap
        heap.insert(sum);

    // Continue the loop until only one node (the root) remains in the heap
    } while (heap.getSize() > 1);

    // Return the root of the Huffman tree
    return heap.extractMin();
}



// Function to delete Huffman Tree
void erase_The_Tree(CodewordNode* root) {
    if (root != nullptr) {
        erase_The_Tree(root->left);
        erase_The_Tree(root->right);
        delete root;
    }
}


// Huffman Encoding methods
void HuffmanEncoding::generateAlphabetCode(char* trainFilePath, char* resultFilePath) {
    try {
        // Array to store the_occurences of ASCII characters
        int the_occurences[128] = {0};
        int sumofChars = 0;

        // Array to store Huffman codes
        HuffmanCode huffmanCodesArray[128]; // Assuming ASCII set
        int theSizeOfhuffmanCodes = 0;

        // Sort Huffman Codes
        mergeSort(huffmanCodesArray, 0, theSizeOfhuffmanCodes - 1);

        // Calculate occurrence_count of each theChar in the file
        std::ifstream file(trainFilePath, std::ifstream::in);
        if (!file.is_open()) {
            throw std::ios_base::failure("Failed to open the training file");
        }

        
       char c;

// Loop through the file stream until there are no more characters left to read
for (; file >> std::noskipws >> c;) {
    // Check if the theChar is within the ASCII range (0-127)
    if (c >= 0 && c < 128) {
        // Increment the count of occurrences of the current theChar
        the_occurences[c]++;
        // Increment the total count of characters processed
        sumofChars++;
    }
}


        file.close();

        // Build Huffman Tree
        CodewordNode* root = createHuffmanTree(the_occurences);

        // Array to store Huffman codes
        std::string huffmanCodes[128];
        generateCodes(root, "", huffmanCodesArray, theSizeOfhuffmanCodes);

        // Open file to write Huffman Codes
        std::ofstream resultFile(resultFilePath, std::ofstream::out);
        if (!resultFile.is_open()) {
            throw std::ios_base::failure("Failed to open the result file to write Huffman Codes");
        }

    
        char probabilityStr[32];

        
int i = 0;  // Initialize loop counter

// Loop through Huffman codes array
while (i < theSizeOfhuffmanCodes) {
    // Calculate probability of theChar occurrence
    double probability = static_cast<double>(the_occurences[huffmanCodesArray[i].theChar]) / sumofChars;

    // Convert probability to string with 6 decimal places
    sprintf(probabilityStr, "%.6f", probability);

    // Check if theChar is newline theChar
    if (huffmanCodesArray[i].theChar == '\n') {
        // Write newline theChar, probability, and Huffman code to result file
        resultFile << "\"\\n\" \"" << probabilityStr << "\" \"" << huffmanCodesArray[i].code << "\"\n";
    } else {
        // Write theChar, probability, and Huffman code to result file
        resultFile << "\"" << huffmanCodesArray[i].theChar << "\" \"" << probabilityStr << "\" \"" << huffmanCodesArray[i].code << "\"\n";
    }

    // Move to next element in Huffman codes array
    ++i;
}



     resultFile.close();
        erase_The_Tree(root); // Ensure to delete the tree to prevent memory leaks
    } catch (const std::ios_base::failure &e) {
        std::cerr << "I/O Error: " << e.what() << std::endl;
    } catch (...) {
        std::cerr << "An unknown BUG happened" << std::endl;
    }
}

HuffmanMap::HuffmanMap() : size(0) {}

void HuffmanMap::insert(char theChar, const std::string& code) {
    int i = 0;
    
    // Iterate through the existing codes
    do {
        // If the character already exists in the map, update its code
        if (codes[i].theChar == theChar) {
            codes[i].code = code;
            return;
        }
        i++;
    } while (i < size); // Continue until the end of the map is reached

    // If the character doesn't exist in the map and there is space available
    if (size < MAX_CHAR) {
        codes[size++] = {theChar, code}; // Insert the character with its code
    } else {
        // If the map has reached its capacity, issue a warning
        std::cerr << "Warning: the cap has reached for Hufman." << std::endl;
    }
}


std::string HuffmanMap::getCode(char theChar) {
    int i = 0; // Initialize loop counter
    while (i < size) { // Continue loop until i reaches size
        if (codes[i].theChar == theChar) { // Check if theChar matches codes[i].theChar
            return codes[i].code; // Return the code if found
        }
        i++; // Increment i to move to the next element
    }
    return ""; // Return an empty string if theChar is not found
}

void enquireHuffmanCodes(char* huffmanCodeFilePath, HuffmanMap& huffmanMap) {
    std::ifstream file(huffmanCodeFilePath);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open the Huffman code file");
    }

    std::string line;
    while (std::getline(file, line)) {
    std::istringstream lineStream(line);
    std::string key, probability, code;

    // Check if the line is for newline theChar explicitly
    switch (line.find("\"\\n\"")) {
        case std::string::npos: {
            // Normal theChar
            if (!(lineStream >> std::quoted(key) >> probability >> std::quoted(code))) {
                std::cerr << "Warning: Failed to parse line '" << line << "'" << std::endl;
                continue;
            }
            if (!key.empty()) {
                huffmanMap.insert(key[0], code); // Insert normal theChar
            }
            break;
        }
        default: {
            // This line represents newline theChar
            if (!(lineStream >> std::quoted(key) >> probability >> std::quoted(code))) {
                std::cerr << "Warning: Failed to parse line '" << line << "'" << std::endl;
                continue;
            }
            huffmanMap.insert('\n', code); // Insert newline theChar
            break;
        }
    }

}

    file.close();
}


void HuffmanEncoding::encodeText(char* testASCIIFilePath, char* huffmanCodeFilePath, char* resultFilePath) {
    try {
        // Load Huffman codes into a map
        HuffmanMap huffmanMap;
        enquireHuffmanCodes(huffmanCodeFilePath, huffmanMap);

      // Open the input file and the output file
        std::ifstream testFile(testASCIIFilePath, std::ios::binary);
        std::ofstream encodedFile(resultFilePath, std::ios::binary);
        if (!testFile.is_open() || !encodedFile.is_open()) {
            throw std::runtime_error("Failed to open files");
        }

        // Set up buffer for reading and writing
        constexpr int BUFFER_SIZE = 1024; // Adjust buffer size as needed
        char inputBuffer[BUFFER_SIZE];
        std::string outputBuffer;
        
        // Read the input file in chunks and encode it
        while (testFile.read(inputBuffer, BUFFER_SIZE)) {
            for (int i = 0; i < testFile.gcount(); ++i) {
                outputBuffer += huffmanMap.getCode(inputBuffer[i]);
            }
            if (outputBuffer.size() >= BUFFER_SIZE) {
                encodedFile << outputBuffer;
                outputBuffer.clear();
            }
        }

        // Process remaining characters
        for (int i = 0; i < testFile.gcount(); ++i) {
            outputBuffer += huffmanMap.getCode(inputBuffer[i]);
        }
        if (!outputBuffer.empty()) {
            encodedFile << outputBuffer;
        }

        // Close the files
        testFile.close();
        encodedFile.close();
    } catch (const std::runtime_error &e) {
        std::cerr << "Runtime exception: " << e.what() << std::endl;
    } catch (...) {
        std::cerr << "An unknown error occurred" << std::endl;
    }
}



// Node structure for trie
struct TrieNode {
    char theChar;
    TrieNode* children[2]; // Assuming binary encoding (0 and 1)
    TrieNode(char c) : theChar(c) {
        children[0] = nullptr;
        children[1] = nullptr;
    }
};

class Trie {
public:
    TrieNode* root;

    Trie() {
        root = new TrieNode('\0'); // Dummy root
    }

    // Insert a Huffman code into the trie
    void insert(const std::string& code, char theChar) {
        TrieNode* curr = root;
        for (char bit : code) {
            int index = bit - '0'; // Convert char '0' or '1' to index 0 or 1
            if (!curr->children[index]) {
                curr->children[index] = new TrieNode('\0');
            }
            curr = curr->children[index];
        }
        curr->theChar = theChar; // Mark leaf node with the character
    }

    // Search for a Huffman code in the trie
    char search(const std::string& code) {
        TrieNode* curr = root;
        for (char bit : code) {
            int index = bit - '0'; // Convert char '0' or '1' to index 0 or 1
            if (!curr->children[index]) {
                return '\0'; // Code not found
            }
            curr = curr->children[index];
        }
        return curr->theChar; // Return the character at leaf node
    }
};


void enquireHuffmanCodes(char* huffmanCodeFilePath, Trie& huffmanTrie) {
    std::ifstream file(huffmanCodeFilePath);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open the Huffman code file");
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream lineStream(line);
        std::string key, probability, code;

        // Check if the line is for newline character explicitly
        switch (line.find("\"\\n\"")) {
            case std::string::npos: {
                // Normal character
                if (!(lineStream >> std::quoted(key) >> probability >> std::quoted(code))) {
                    std::cerr << "Warning: Failed to parse line '" << line << "'" << std::endl;
                    continue;
                }
                if (!key.empty()) {
                    huffmanTrie.insert(code, key[0]); // Insert normal character
                }
                break;
            }
            default: {
                // This line represents newline character
                if (!(lineStream >> std::quoted(key) >> probability >> std::quoted(code))) {
                    std::cerr << "Warning: Failed to parse line '" << line << "'" << std::endl;
                    continue;
                }
                huffmanTrie.insert(code, '\n'); // Insert newline character
                break;
            }
        }
    }

    file.close();
}

void HuffmanEncoding::decodeText(char* testEncodedFilePath, char* huffmanCodeFilePath, char* resultFilePath) {
    // Open the encoded file and the output file using buffered I/O
    FILE* encodedFile = fopen(testEncodedFilePath, "rb");
    FILE* resultFile = fopen(resultFilePath, "wb");

    // Check if files were opened successfully
    if (!encodedFile || !resultFile) {
        std::cerr << "Error: Failed to open files" << std::endl;
        if (encodedFile) fclose(encodedFile);
        if (resultFile) fclose(resultFile);
        return;
    }

    // Load Huffman codes into a trie for efficient decoding
    Trie huffmanTrie;
    enquireHuffmanCodes(huffmanCodeFilePath, huffmanTrie);

    // Set up buffer for reading encoded data and writing decoded data
    constexpr int BUFFER_SIZE = 1024; // Adjust buffer size as needed
    char inputBuffer[BUFFER_SIZE];
    char outputBuffer[BUFFER_SIZE];
    std::string currentCode;
    size_t outputIndex = 0;

    // Read the encoded data in chunks and decode it
    while (size_t bytesRead = fread(inputBuffer, 1, BUFFER_SIZE, encodedFile)) {
        for (size_t i = 0; i < bytesRead; ++i) {
            currentCode += inputBuffer[i];
            char decodedChar = huffmanTrie.search(currentCode);
            if (decodedChar != '\0') {
                outputBuffer[outputIndex++] = decodedChar;
                if (outputIndex >= BUFFER_SIZE) {
                    fwrite(outputBuffer, sizeof(char), outputIndex, resultFile);
                    outputIndex = 0;
                }
                currentCode.clear();
            }
        }
    }

    // Write remaining decoded characters from the buffer to the output file
    if (outputIndex > 0) {
        fwrite(outputBuffer, sizeof(char), outputIndex, resultFile);
    }

    // Close the files
    fclose(encodedFile);
    fclose(resultFile);
}
